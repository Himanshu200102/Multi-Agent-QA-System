﻿param(
  [string]$Goal = "Toggle WiFi off then back on"
)

$ErrorActionPreference = "Stop"

# 1) Clean
.\scripts\clean.ps1

# 2) Run demo (LLM if key present)
$useLLM = [bool]$env:OPENAI_API_KEY
if ($useLLM) {
  .\scripts\run-demo.ps1 -UseLLM -Goal $Goal
} else {
  .\scripts\run-demo.ps1 -Goal $Goal
}

# 3) Package
.\scripts\package.ps1
