from __future__ import annotations
import argparse, json, os
from .agents.planner import Planner
from .agents.executor import Executor
from .agents.verifier import Verifier
from .agents.supervisor import Supervisor
from .utils.schemas import LogRecord
from .envs.mock_android import MockAndroidEnv

def save(path: str, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--goal", type=str, default="Toggle Wi‑Fi off and on")
    parser.add_argument("--env", type=str, choices=["mock"], default="mock")
    parser.add_argument("--logs_dir", type=str, default="./logs")
    parser.add_argument("--llm_planner", action="store_true", help="Use LLM to generate the plan (cached).")
    parser.add_argument("--model", type=str, default=None, help="Override LLM model name (e.g., gpt-4o-mini)")
    args = parser.parse_args()

    # 1) Create agents
    planner = Planner(use_llm=args.llm_planner, model=args.model)
    verifier = Verifier(goal=args.goal)
    supervisor = Supervisor(model=args.model)

    # 2) Environment
    if args.env == "mock":
        env = MockAndroidEnv()
    else:
        raise ValueError("Only 'mock' is implemented in this starter.")

    executor = Executor(env)

    # 3) Plan
    plan = planner.plan(args.goal)

    # 4) Loop
    log_records = []
    log_records.append(LogRecord(event="plan", payload=plan.model_dump()).model_dump())
    status = "unknown"
    final_verify_pass = None

    # for the pretty table in the report
    steps_summary = []

    for step in plan.steps:
        # Execute
        res = executor.execute(step.intent, step.target, step.params)
        log_records.append(LogRecord(event="action", payload={
            "step_id": step.id,
            "intent": step.intent,
            "target": step.target,
            "ok": res.ok,
            "message": res.message,
            "observation": res.observation.model_dump()
        }).model_dump())

        bug = None
        if not res.ok:
            bug = f"Execution failed: {res.message}"

        # Verify (now pass params too)
        ver = verifier.verify_step(step.intent, step.target, step.params, res.observation)
        log_records.append(LogRecord(event="verify", payload={
            "step_id": step.id,
            "passed": ver.passed,
            "reason": ver.reason,
            "need_replan": ver.need_replan,
        }).model_dump())

        # Collect for the step table
        steps_summary.append({
            "id": step.id,
            "intent": step.intent,
            "target": step.target or "",
            "action_ok": res.ok,
            "action_msg": res.message,
            "verify_passed": ver.passed,
            "verify_reason": ver.reason
        })

        if step.intent == "verify":
            final_verify_pass = ver.passed

        if bug:
            log_records.append(LogRecord(event="replan", payload={"reason": bug}).model_dump())
            status = "failed"
            break

    # 5) Finish
    status = "passed" if final_verify_pass is not False else "failed"
    log_records.append(LogRecord(event="finish", payload={"status": status}).model_dump())

    # 6) Persist
    run_path = os.path.join(args.logs_dir, "qa_run.json")
    save(run_path, log_records)

    # 7) Supervisor report
    report = supervisor.summarize(args.goal, log_records)

    # 8) Append a neat step table to the report
    header = "| Step | Intent | Target | Action OK | Verify | Reason |\n|---:|---|---|:---:|:---:|---|\n"
    rows = "\n".join([
        f"| {s['id']} | {s['intent']} | {s['target']} | {'✅' if s['action_ok'] else '❌'} | {'✅' if s['verify_passed'] else '❌'} | {s['verify_reason']} |"
        for s in steps_summary
    ])
    report_full = report + "\n\n### Step Summary\n\n" + header + rows + f"\n\n**Final status:** {status}\n"

    with open(os.path.join(args.logs_dir, "report.md"), "w", encoding="utf-8") as f:
        f.write(report_full)

    print(f"Run status: {status}")
    print(f"Logs: {run_path}")
    print(f"Report: {os.path.join(args.logs_dir, 'report.md')}")

if __name__ == "__main__":
    main()
