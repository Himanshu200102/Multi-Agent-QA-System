# QualGent Multi‑Agent QA (CPU‑friendly starter)

This repository is a **from-scratch, CPU‑only** implementation of the coding challenge:
a minimal multi‑agent system (Planner → Executor → Verifier → Supervisor) that
executes and verifies a single Android QA task. It ships with a **mock Android**
environment so you can prove your orchestration without a GPU or emulator.
You can later swap `MockAndroidEnv` for a real Android simulator.

## Quick start (no GPU, no emulator)

```bash
# 1) Create and activate a virtual environment (Python 3.11 recommended)
python -m venv .venv
source .venv/bin/activate  # on Windows: .venv\Scripts\activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) Copy env template and (optionally) set OPENAI_API_KEY
cp .env.example .env
# (You can leave it empty to run fully offline; the code falls back to rules.)

# 4) Run the end‑to‑end demo on the mock environment
python -m qa_agents.run_test --goal "Toggle Wi‑Fi off and on" --env mock

# 5) Inspect outputs
ls logs/
# qa_run.json   report.md
```

## Real Android integration (later)

This starter uses `MockAndroidEnv` for portability. To integrate a real emulator:
- Implement `AndroidWorldEnv` (same interface as `MockAndroidEnv`) that connects to your chosen Android simulator/API.
- Replace `--env mock` with `--env android` and ensure you provide the required SDK/emulator setup.
- The rest of the pipeline (agents, schemas, logging) remains identical.

## Project layout

```
qa_agents/
  src/qa_agents/
    agents/           # Planner, Executor, Verifier, Supervisor
    envs/             # MockAndroidEnv (swap later for real env)
    llm/              # LLM client (OpenAI) with offline fallback
    utils/            # Schemas, cache, logging helpers
    run_test.py       # Orchestrator entrypoint
  tests/
  logs/
  scripts/
```

## Why this design?

- **Deterministic demo**: The entire pipeline runs without external services, so reviewers can reproduce results instantly.
- **LLM‑first, rules‑fallback**: You can turn on OpenAI for Planner/Supervisor once you add an API key; otherwise it uses small heuristic policies.
- **Composable**: Agents exchange typed messages (Pydantic schemas), making it easy to add a new agent (e.g., a Vision Grounder) without changing others.

## Submission checklist

- [x] Single command demo (`python -m qa_agents.run_test ...`)
- [x] JSON logs with step‑level trace
- [x] Report (`logs/report.md`) summarizing plan, bugs, and recovery attempts
- [x] Tests (`pytest -q`) for basic invariants

---

**Note:** This project intentionally avoids heavyweight simulator dependencies so you can focus on the
agentic logic. Swap the environment when you're ready.
